package Section2;
public class ProblemSet2_1
{
    public static void main(String[] args)
    {
        System.out.println("  XXXX  ");
        System.out.println(" X    X ");
        System.out.println("X X  X X");
        System.out.println("X      X");
        System.out.println("X X  X X");
        System.out.println("X  XX  X");
        System.out.println(" X    X ");
        System.out.println("  XXXX  ");
    }   
}