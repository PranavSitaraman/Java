package Section2;
public class ProblemSet2_2
{
    public static void main(String[] args)
    {
        // An Image of a PS2 Controller
        System.out.println("      _=====_                               _=====_");
        System.out.println("     / _____ \\                             / _____ \\       ");
        System.out.println("   +.-\'_____\'-.---------------------------.-\'_____\'-.+     ");
        System.out.println("  /   |     |  \'.        S O N Y        .\'  |  _  |   \\    ");
        System.out.println(" / ___| /|\\ |___ \\                     / ___| /_\\ |___ \\   ");
        System.out.println("/ |      |      | ;  __           _   ; | _         _ | ;  ");
        System.out.println("| | <---   ---> | | |__|         |_:> | ||_|       (_)| |  ");
        System.out.println("| |___   |   ___| ;SELECT       START ; |___       ___| ;  ");
        System.out.println("|\\    | \\|/ |    /  _     ___      _   \\    | (X) |    /|  ");
        System.out.println("| \\   |_____|  .\',\'\" \"\', |___|  ,\'\" \"\', \'.  |_____|  .\' |  ");
        System.out.println("|  \'-.______.-\' /       \\ANALOG/       \\  \'-._____.-\'   |  ");
        System.out.println("|               |       |------|       |                |  ");
        System.out.println("|              /\\       /      \\       /\\               |  ");
        System.out.println("|             /  \'.___.\'        \'.___.\'  \\              |  ");
        System.out.println("|            /                            \\             |  ");
        System.out.println(" \\          /                              \\           /   ");
        System.out.println("  \\________/                                \\_________/    ");
        System.out.println("                    PS2 CONTROLLER                         ");
    } 
}
